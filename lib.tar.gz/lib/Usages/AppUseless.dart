//size Text
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

double Size_Title(){
  return 25;
}

double Size_Normal(){
  return 20;
}
//Palette
Color  PrimaryColor(){
  return Colors.lightBlue[700];
}

Color SecondaryColor(){
  return Colors.lightBlue[800];
}
Color ThirdColor(){
  return Colors.lightBlue[900];
}


