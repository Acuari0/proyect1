/*import 'package:flutter_blue/flutter_blue.dart';

class BluetoothClass {
  BluetoothDevice device;
  void setDevice (BluetoothDevice a)=>this.device=a;
}*/